package b06.bean;

public class FavoriteBean {
	private String color="";
	private String flower="";
	private String music="";
	public void setColor(String color) {
		this.color=color;
	}
	public String getColor() {
		return color;
	}
	public void setFlower(String flower) {
		this.flower=flower;
	}
	public String getFlower() {
		return flower;
	}
	public void setMusic(String music) {
		this.music=music;
	}
	public String getMusic() {
		return music;
	}
}
